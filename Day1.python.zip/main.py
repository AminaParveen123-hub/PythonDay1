#What is Programming ?
#Programming is to tell the computer what to do
#like we program the calculator to calculate any number computer do it fastly than humans
#What is python ?
#Python is easy to understand
#It is platform independent
# used in various fields like AI,ML,DS,etc
#It is open source
#It is a high level language
#What is Module?
#Module means we borrow someone else code and use it without knowning their implementataion
#for example we use the phone without knowing how it works( its backend functionality )
#Modules of 2 types
# Builtin : We dont need to install them
# External: We have to borrow it from outside world
print("Hello World")
print("100 Days of Code")
print(23*12)
#Print is  a function